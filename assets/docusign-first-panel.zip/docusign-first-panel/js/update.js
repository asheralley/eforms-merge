// Custom js updates 2018

